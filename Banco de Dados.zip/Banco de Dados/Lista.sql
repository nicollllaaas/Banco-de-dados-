CREATE TABLE NotaFiscal
(
    id_nf INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,
    data DATE
);

CREATE TABLE Produtos
(
    id_item INT,
    cod_prod INT,
    valor_unit FLOAT,
    quantidade INT,
    desconto INT,
    id_nf INT,
    PRIMARY KEY (id_item,cod_prod,id_nf),
    FOREIGN KEY (id_nf) REFERENCES NotaFiscal (id_nf)
);

INSERT INTO NotaFiscal VALUES 
    (1,2020-09-27),
    (2,2023-03-27),
    (3,2023-03-27),
    (4,2007-05-12),
    (5,2009-12-20),
    (6,2018-07-17),
    (7,2021-02-09);

INSERT INTO Produtos VALUES
    (1,1,25,10,5,1),
    (2,2,13.5,3,NULL,1),
    (3,3,15,2,NULL,1),
    (4,4,10,1,NULL,1),
    (5,5,30,1,NULL,1),
    (1,3,15,4,NULL,2),
    (2,4,10,5,NULL,2),
    (3,5,30,7,NULL,2),
    (1,1,25,5,NULL,3),
    (2,4,10,4,NULL,3),
    (3,5,30,5,NULL,3),
    (4,2,13.5,7,NULL,3),
    (1,5,30,10,15,4),
    (2,4,10,12,5,4),
    (3,1,25,13,5,4),
    (4,2,13.5,15,5,4),
    (1,3,15,3,NULL,5),
    (2,5,30,22,NULL,5),
    (1,1,25,22,15,6),
    (2,3,15,25,20,6),
    (1,1,25,10,3,7),
    (2,2,13.5,10,4,7),
    (3,3,15,10,4,7),
    (4,5,30,10,1,7);


SELECT id_nf,id_item,cod_prod,valor_unit FROM Produtos WHERE desconto IS NULL;

SELECT id_nf,id_item,cod_prod,valor_unit,valor_unit-(valor_unit*(desconto/100)) as valor_vendido FROM Produtos WHERE desconto IS NOT NULL;

UPDATE Produtos SET desconto=0 WHERE desconto IS NULL;

SELECT id_nf,id_item,cod_prod,valor_unit,valor_unit*quantidade as valor_total,desconto,valor_unit-(valor_unit*(desconto/100)) as valor_vendido FROM Produtos;

SELECT id_nf,SUM(quantidade*valor_unit) as valor_total  FROM Produtos GROUP BY id_nf;

SELECT id_nf,SUM(quantidade*valor_unit) as valor_total,valor_unit-(valor_unit*(desconto/100)) as valor_vendido FROM Produtos GROUP BY id_nf;

SELECT cod_prod, quantidade FROM Produtos WHERE quantidade IN (SELECT MAX(quantidade) FROM Produtos) GROUP BY cod_prod;

SELECT id_nf,cod_prod,quantidade FROM Produtos WHERE quantidade>10 GROUP BY id_nf,cod_prod;

SELECT id_nf,SUM(quantidade*valor_unit) as valor_total FROM Produtos GROUP BY id_nf HAVING valor_total > 500;

SELECT cod_prod, AVG(desconto) as media FROM Produtos GROUP BY cod_prod;

SELECT cod_prod,MIN(desconto) as menor,MAX(desconto) as maior, AVG(desconto) as media FROM Produtos GROUP BY cod_prod;

SELECT id_nf,COUNT(quantidade) as qtd_itens FROM Produtos GROUP BY id_nf HAVING qtd_itens>3;









CREATE TABLE Aluno
(
    MAT int,
    nome varchar(100),
    endereco varchar(150),
    cidade varchar(40),
    PRIMARY KEY(MAT)
);

CREATE TABLE Disciplinas
(
    cod_disc varchar(10),
    nome_disc VARCHAR(40),
    carga_hor INT,
    PRIMARY KEY(cod_disc)
);

CREATE TABLE Professores
(
    cod_prof int,
    nome varchar(100),
    endereco varchar(150),
    cidade varchar(40)
);

CREATE TABLE Turma
(
    cod_disc varchar(10),
    cod_turma int,
    cod_prof int,
    ano int,
    horario VARCHAR(10),
    PRIMARY KEY (cod_turma,cod_prof,cod_disc,ano),
    FOREIGN KEY (cod_prof) REFERENCES Professores,
    FOREIGN KEY (cod_disc) REFERENCES Disciplina
);

CREATE TABLE Historico
(
    mat int,
    cod_disc varchar(10),
    cod_turma int,
    cod_prof int,
    ano int,
    frequencia int,
    nota float,
    PRIMARY KEY (cod_turma,cod_prof,cod_disc,ano,mat),
    FOREIGN KEY (mat) REFERENCES Aluno,
    FOREIGN KEY (cod_disc, cod_turma, cod_prof, ano) REFERENCES Turma
);

INSERT INTO Aluno VALUES
(2015010101, 'JOSE DE ALENCAR', 'RUA DAS ALMAS', 'NATAL'),
(2015010102, 'JOÃO JOSÉ', 'AVENIDA RUY CARNEIRO', 'JOÃO PESSOA'),
(2015010103, 'MARIA JOAQUINA', 'RUA CARROSSEL', 'RECIFE'),
(2015010104, 'MARIA DAS DORES', 'RUA DAS LADEIRAS','FORTALEZA'),
(2015010105, 'JOSUÉ CLAUDINO DOS SANTOS', 'CENTRO', 'NATAL'),
(2015010106, 'JOSUÉLISSON CLAUDINO DOS SANTOS', 'CENTRO', 'NATAL');

INSERT INTO Disciplinas VALUES
(BD, 'BANCO DE DADOS', 100),
(POO, 'PROGRAMAÇÃO COM ACESSO A BANCO DE DADOS', 100),
(WEB, 'AUTORIA WEB', 50),
(ENG, 'ENGENHARIA DE SOFTWARE', 80);

INSERT INTO Professores VALUES
(212131, 'NICKERSON FERREIRA', 'RUA MANAÍRA', 'JOÃO PESSOA'),
(122135, 'ADORILSON BEZERRA', 'AVENIDA SALGADO FILHO', 'NATAL'),
(192011, 'DIEGO OLIVEIRA', 'AVENIDA ROBERTO FREIRE', 'NATAL');

INSERT INTO Turma VALUES
('BD', 1, 212131, 2015, '11H-12H'),
('BD', 2, 212131, 2015, '13H-14H'),
('POO', 1, 192011, 2015, '08H-09H'),
('WEB', 1, 192011, 2015, '07H-08H'),
('ENG', 1, 122135, 2015, '10H-11H');

INSERT INTO Historico VALUES
(1,1,1,1,2015,82,10),
(2,2,2,	2,2015,78,7),
(3,3,3,3,2015,3,4.5),
(4,4,4,4,2015,90,17.8);

SELECT mat FROM Historico WHERE cod_disc LIKE '%BD%' AND ano=2015 AND nota<5;

SELECT mat,AVG(nota) FROM Historico WHERE ano=2015 AND cod_disc='POO' GROUP BY mat;

SELECT mat,nota FROM Historico WHERE ano=2015 AND cod_disc='POO' AND nota IN(SELECT AVG(nota) FROM Produtos) GROUP BY mat;

SELECT COUNT(cidade) FROM Alunos WHERE cidade LIKE '%Natal%';